import Detail from "./Detail"

function SearchList({records}) {

    return <div>
        {records.map((rec) => <Detail data={rec} key={rec.thumbnailUrl } />)}
    </div>

}

export default SearchList;