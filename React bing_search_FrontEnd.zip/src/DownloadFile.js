import React, { useState, useEffect } from 'react';
import axios from 'axios';

const DownloadFile = () => {
    const [csvData, setCsvData] = useState([]);

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async (e) => {
        try {
         
            const result = await axios.get('https://localhost:7027/Location/file'); 
            setCsvData(result.data);
        } catch (error) {
            console.error('Error fetching CSV data:', error);
        }
    };

    const downloadCsv = () => {
        
        const csvBlob = new Blob([csvData.join('\n')], { type: 'text/csv' });

        
        const a = document.createElement('a');
        const url = window.URL.createObjectURL(csvBlob);
        a.href = url;
        a.download = 'data.csv';

      
        document.body.appendChild(a);
        a.click();

      
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    };

    return (
        <form>
        <div>
            <h1>CSV Data</h1>
            <button class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800"  onClick={downloadCsv}>Download CSV</button>
            <ul>
                {csvData.map((row, index) => (
                    <li key={index}>{row}</li>
                ))}
            </ul>
            </div></form>
    );
};

export default DownloadFile;