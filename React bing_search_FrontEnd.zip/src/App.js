import "./App.css";
import { useState } from "react";
import SearchInput from "./SearchInput";
import SearchList from "./SearchList";
import axios from "axios";
import AddLocation from "./AddLocation";
import ShowLocations from "./ShowLocations";
import DownloadFile from "./DownloadFile";


function App() {
  const [query, setQuery] = useState("");
  const [searchedResult, setSearchedResult] = useState([]);

  const handleSearch = (value) => {
    setQuery(value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault()
    const endpoint = `https://api.bing.microsoft.com/v7.0/search?q=${query}`;
    try {
       const response = await axios.get(endpoint, {
         headers: {
           "Ocp-Apim-Subscription-Key":
                   "enter bing key here",
         },
       });
       setSearchedResult(response.data.webPages.value);
      setQuery("");
    } catch (error) {
      console.log(error.message);
    }
  };
    return (


        <div>

           
                <div className="mb-10">
                    <h1>Manage Locations</h1>
                    <AddLocation />
                <ShowLocations />
                <h1>Download File</h1>
                <DownloadFile/>
                </div>

      <SearchInput
        query={query}
        onSearch={handleSearch}
        onSubmit={handleSubmit}
      />
      {searchedResult && <SearchList records={searchedResult} />}
    </div>
  );
}

export default App;
