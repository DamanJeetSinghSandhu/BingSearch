import React, { useState, useEffect } from "react";
import axios from "axios";

function ShowLocations() {
  const [locations, setLocations] = useState([]);

  useEffect(() => {
    const fetchLocations = async () => {
        const apiURL = "https://localhost:7027/Location";
      try {
        const response = await axios.get(apiURL);
        setLocations(response.data);
      } catch (error) {
        console.error("Error fetching locations:", error);
      }
    };

    fetchLocations();
  }, []);

  return (
    <div>
      <h2>Locations</h2>
      <ul>
        {locations.map((location, index) => (
          <li key={index}>
                {location.name} (Available from {location.availFrom} to{" "}
                {location.availTo})
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ShowLocations;
