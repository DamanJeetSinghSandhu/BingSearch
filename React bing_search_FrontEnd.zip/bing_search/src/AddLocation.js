import React, { useState } from "react";
import axios from "axios";

function AddLocation() {
  const [name, setName] = useState("");
  const [availFrom, setAvailFrom] = useState("");
    const [availTo, setAvailTo] = useState("");
    const [availFHH, setAvailFHH] = useState("");
    const [availFMM, setAvailFMM] = useState("");
    const [availTHH, setAvailTHH] = useState("");
    const [availTMM, setAvailTMM] = useState("");


  const handleSubmit = async (e) => {
    e.preventDefault();
    const locationData = {
        name: name,
        availFrom: availFHH + ':' + availFMM+ ':'+ '00',
        availTo: availTHH + ':' + availTMM + ':' + '00',

    };


      const apiURL = "https://localhost:7027/Location";
    try {
      await axios.post(apiURL, locationData);
      alert("Location added successfully");
      setName("");
      setAvailFrom("");
      setAvailTo("");
    } catch (error) {
      console.error("Error adding location:", error);
      alert("Failed to add location");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Location Name"
        required
          />
          <div className="mb-6">
          <input 
        type="text"
              value={availFHH}
              onChange={(e) => setAvailFHH(e.target.value)} placeholder="Available From:enter hours "
        required
              /><p></p>

              <input
                  type="text"
                  value={availFMM}
                  onChange={(e) => setAvailFMM(e.target.value)} placeholder="Available From: enter minutes"
                  required
              />
            

          </div>
          <div className="mb-6">
          <input 
        type="text"
        value={availTHH}
              onChange={(e) => setAvailTHH(e.target.value)} placeholder="Availabr To: enter hours"
        required
              />
              <p></p>
              <input
                  type="text"
                  value={availTMM}
                  onChange={(e) => setAvailTMM(e.target.value)} placeholder="Availabr To: enter minutes"
                  required
              />
              
          </div>
          <button class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800" type="submit">Add Location</button>
    </form>
  );
}

export default AddLocation;
